# Attributions

Every uploaded asset carried by this save (`starmap.json`), what uses it, and the
provenance recorded for it. Written automatically on export.

**1 model, 2 images.**

> 1 asset has no provenance recorded at all.
> That is fine for art you made yourself. For anything downloaded, fill it in.

## 3D models

### assets/models/c0ffee.glb
- Used by: Contract Runner (Contract Reach)
- Title: Runner hull
- _No provenance recorded._

## Images

### assets/images/planet-b.png
- Used by: Bellwether (Contract Reach)
- Credit: A Painter
- Licence: CC BY 4.0

### assets/images/player/asset-sector-map.png
- Used by: Sector map (map background)
- Title: Sector map
- Credit: A Cartographer
- Licence: CC BY 4.0
- Source: https://example.test/map

---

Edit the provenance in the app (the model dialog, or the picture controls beside it) and
export again to refresh this file. Bundled starter models from NASA are public domain.
