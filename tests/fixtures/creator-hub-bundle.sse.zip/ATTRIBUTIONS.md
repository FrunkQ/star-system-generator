# Attributions

Every uploaded asset carried by this save (`starmap.json`), what uses it, and the
provenance recorded for it. Written automatically on export.

**1 model, 3 images.**

> 1 asset has no provenance recorded at all.
> That is fine for art you made yourself. For anything downloaded, fill it in.

## 3D models

### assets/models/bd80fe63d2ad7dff5eb09f2ff4d4fa5f33ecb4c5c62bb6059b0b7ae0e38b6da4.glb
- Used by: Contract Runner (Contract Reach), Second Runner (Contract Reach)
- Title: Runner hull
- Credit: A Modeller
- Licence: CC BY 4.0
- Source: https://example.test/runner-hull

## Images

### assets/images/planet-b.png
- Used by: Bellwether (Contract Reach)
- Title: Bellwether from orbit
- Credit: A Painter
- Licence: CC BY 4.0
- Source: https://example.test/bellwether

### assets/images/moon-c.png
- Used by: Tally (Contract Reach)
- _No provenance recorded._

### assets/images/player/asset-sector-map.png
- Used by: Sector map (map background)
- Title: Sector map
- Credit: A Cartographer
- Licence: CC BY 4.0
- Source: https://example.test/map

## Content from other cartographers

Objects in this campaign were copied from the maps below. They are the work of their
creators, and this credit travels with the save.

### Local Neighbourhood
- Cartographer: frunk
- Source: https://hub.test/s/local-neighbourhood
- Found on: StarSystemX Explorers
- 1 object in this campaign came from it.

### An Older Map
- Cartographer not recorded (the map was copied before the library carried that).
- Source: https://hub.test/s/older-map
- Lineage: from Alpha by alice, via Beta by bob, via An Older Map
- 1 object in this campaign came from it.

---

Edit the provenance in the app (the model dialog, or the picture controls beside it) and
export again to refresh this file. Bundled starter models from NASA are public domain.
