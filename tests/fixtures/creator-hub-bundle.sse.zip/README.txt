Star System Explorer save bundle (starmap).

starmap.json is the data - edit it in any text editor.
assets/models/*.glb are ship models, named by content hash.
assets/images/*   are uploaded pictures, named by the node they belong to.
assets/images/player/* are player-view graphics: logos, overlays and the map background.
ATTRIBUTIONS.md   who made the art and under what licence - read it before sharing.

Replace an asset by overwriting the file, keeping its name. Re-zip with these paths intact.
A plain .json save (no assets) still loads, and always will.
