# Attributions

Every uploaded asset carried by this save (`system.json`), what uses it, and the
provenance recorded for it. Written automatically on export.

**1 model, 1 image.**

> 1 asset has no provenance recorded at all.
> That is fine for art you made yourself. For anything downloaded, fill it in.

## 3D models

### assets/models/065ffd682c64615af76a68f074ce65485b0bcb4d41bf9bd1d5397eb7fd0b5bee.glb
- Used by: Survey Tender
- Title: Tender hull
- _No provenance recorded._

## Images

### assets/images/planet-quay.png
- Used by: Quay
- Title: Quay
- Credit: A Painter
- Licence: CC0 1.0

---

Edit the provenance in the app (the model dialog, or the picture controls beside it) and
export again to refresh this file. Bundled starter models from NASA are public domain.
