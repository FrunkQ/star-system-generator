# Attributions

Every uploaded asset carried by this save (`system.json`), what uses it, and the
provenance recorded for it. Written automatically on export.

**1 model, 1 image.**

> 1 asset has no provenance recorded at all.
> That is fine for art you made yourself. For anything downloaded, fill it in.

## 3D models

### assets/models/065ffd682c64615af76a68f074ce65485b0bcb4d41bf9bd1d5397eb7fd0b5bee.glb
- Used by: Survey Tender
- Title: Tender hull
- _No provenance recorded._

## Images

### assets/images/planet-quay.png
- Used by: Quay
- Title: Quay
- Credit: A Painter
- Licence: CC0 1.0

## What the app itself brought

These belong to neither you nor the person who made this campaign: they ship with Star System
Explorer and travel in this save because the campaign uses them. Several carry a
share-alike or attribution licence, which means the credit has to travel too - so it is
written here rather than left behind in the app.

### Art and models

### Planet type images
- Credit: Pablo Carlos Budassi
- Licence: CC BY-SA 4.0
- Source: https://pablocarlosbudassi.com/2021/02/planet-types.html

### Star images
- Credit: Beyond Universe Wiki, on Fandom
- Licence: CC BY-SA 3.0 US
- Source: https://beyond-universe.fandom.com/wiki/

### Star-type illustration: orange giant (Arcturus)
- Credit: Pablo Carlos Budassi, Wikimedia Commons
- Licence: CC BY-SA 4.0

### Star-type illustration: red giant
- Credit: NASA's Goddard Space Flight Center / Chris Smith (KBRwyle)
- Licence: Public domain
- Source: https://science.nasa.gov/universe/stars/types/

### Magnetar image
- Credit: ESO / L. Calcada
- Licence: CC BY 4.0
- Source: https://www.eso.org/public/images/eso1415a/

### Red supergiant: an artist's reconstruction of WOH G64
- Credit: ESO / L. Calcada
- Licence: CC BY 4.0
- Source: https://www.eso.org/public/images/eso2417a/

### Starmap background (the default Milky Way)
- Credit: ESO / S. Brunier
- Licence: CC BY 4.0
- Source: https://www.eso.org/public/images/eso0932a/

### H-R diagram background
- Credit: ESO
- Licence: CC BY 4.0
- Source: https://www.eso.org/public/images/eso0728c/

### Black-hole accretion disc image
- Credit: NASA's Goddard Space Flight Center / Jeremy Schnittman
- Licence: Public domain
- Source: https://svs.gsfc.nasa.gov/13232

### Asteroid and comet images: 253 Mathilde (NEAR), 433 Eros (NEAR Shoemaker), 16 Psyche illustration, comet Hartley 2 (EPOXI)
- Credit: NASA / JPL-Caltech / UMD
- Licence: Not subject to copyright

### Starter spacecraft models: ISS, Hubble, Cassini-Huygens, Juno, Voyager, Mars Reconnaissance Orbiter
- Credit: NASA
- Licence: Public domain
- Source: https://github.com/nasa/NASA-3D-Resources
- Changes: Textured models resampled for bundle size. The protected NASA insignia is not used.

### Weyland-Yutani logo
- Credit: IllaZilla, Wikimedia Commons
- Licence: CC BY-SA 3.0 Unported
- Source: https://commons.wikimedia.org/wiki/File:Weyland-Yutani_cryo-tube.jpg
- Changes: Logo extracted.

### Corporate logos: Interspan, Kelido, Nexum, Terra, TSEC
- Credit: World Zero
- Licence: CC BY 4.0
- Source: https://worldzero.itch.io/

### Astronomy data

The real-sky import and the bundled starmaps are built from these.

### Confirmed exoplanets behind the real-sky import and the bundled starmaps (a snapshot ships with the app)
- Credit: NASA Exoplanet Archive, operated by the California Institute of Technology under contract with NASA under the Exoplanet Exploration Program
- Licence: Acknowledgement required
- Source: https://exoplanetarchive.ipac.caltech.edu/

### Star identification and astrometry; star-name resolution queries it live
- Credit: SIMBAD, operated at CDS, Strasbourg, France
- Licence: Acknowledgement required
- Source: https://simbad.cds.unistra.fr/simbad/

### S-star orbital elements at the galactic centre
- Credit: Gillessen et al. 2017, refined by the GRAVITY Collaboration
- Licence: Cited

---

Edit the provenance in the app (the model dialog, or the picture controls beside it) and
export again to refresh this file.
